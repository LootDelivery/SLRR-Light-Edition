// Author: MisterSir & MikeShinodaSLR
// Developed: 2016
// File: Scale_Innovative_spring.java

package java.game.parts.Scale_Innovative;

import java.render.osd.*;
import java.io.*;
import java.util.*;
import java.util.resource.*;
import java.game.*;
import java.game.cars.*;
import java.game.parts.*;
import java.game.parts.bodypart.*;
import java.game.parts.enginepart.*;
import java.game.parts.rgearpart.*;


public class Scale_Innovative_spring extends MrSir_Spring
{
	public Scale_Innovative_spring( int id )
	{
		super( id );
		int wheelID = getWheelID();		
		setParameters(wheelID);
		restlength = Inch2Meter(length);
		minlength = Inch2Meter(length-2.0);
		maxlength = Inch2Meter(length+1.0);
		brand_prestige_factor = 2.19;
		setParentType(0x001A);		
		name_prefix = "Scale Innovative Series";
		additionalDescription = "This spring is ment to fit with the Scale Innovative Series shock absorbers. It is ride height adjustable and good for drifting applications.";
		calcStuffs();
	}

	public void updatevariables()
	{
		int i = getWheelID();
		if (i==0){
			setRenderType(parentType + 0x001A);
		}else if (i==1){
			setRenderType(parentType + 0x001A);
		}else if (i==2){
			setRenderType(parentType + 0x001B);
		}else if (i==3){
			setRenderType(parentType + 0x001B);
		}
		updateParameters(i);
		super.updatevariables();
	}

	public void setParameters(int i)
	{
		if (i<=1){
			designedMassOnWheel = getMessOnWheel(mass, 50.0, WHL_FRONT);
			length = 7.0;
			setAdjustability(2.0, 1.0, length);
			force = kgfPmm2NPm(8.85);
		}else{			
			designedMassOnWheel = getMessOnWheel(mass, 50.0, WHL_REAR);
			length = 6.5;
			setAdjustability(1.5, 1.5, length);
			force = kgfPmm2NPm(9.7);
		}
		setSide(i);
	}

	public void updateParameters(int i)
	{
		if (i<=1){
			designedMassOnWheel = getMessOnWheel(mass, 50.0, WHL_FRONT);
			setAdjustability(2.0, 1.0, 7.0);
			force = kgfPmm2NPm(8.85);
		}else{			
			designedMassOnWheel = getMessOnWheel(mass, 50.0, WHL_REAR);
			setAdjustability(1.5, 1.5, 6.5);
			force = kgfPmm2NPm(9.7);
		}
		setSide(i);
		calcStuffs();
	}
}
