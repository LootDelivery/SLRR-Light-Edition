package java.game.parts.engines.Nissan_SR;

import java.util.*;
import java.util.resource.*;
import java.game.*;
import java.game.parts.*;
import java.game.cars.*;


public class camshaft_drive_belt extends EnginePart
{
	public camshaft_drive_belt( int id )
	{
		super( id );
		name = "Nissan SR20DE camshaft drive chain";
		description = "";

		value = tHUF2USD(6.730);
		brand_new_prestige_value = 3.35;
		setMaxWear(kmToMaxWear(18000.0));
	}
}
